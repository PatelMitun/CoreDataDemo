//
//  UserModel.swift
//  FestivalityTrial
//
//  Created by TechFlitter Solutions on 11/06/18.
//  Copyright © 2018 TechFlitter Solutions. All rights reserved.
//

import Foundation
import ObjectMapper
import CoreData

class UsersModel: Mappable {
    
    var status: Int64!
    var userModel: [UserModel]!
    
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        status <- map["status"]
        userModel <- map["response"]
    }
}

class UserModel: Mappable {
    let managedContext = CoreDataManager.sharedInstance.getManagedContext()

    var userId: Int64!
    var customFields: CustomField!
    var likes: Int64!
    var media: [Media]!
    
    required init?() {
    }
    
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        userId <- map["id"]
        customFields <- map["customFields"]
        likes <- map["likes"]
        media <- map["media"]
    }
    
    func saveAll(userModel: [UserModel], completion:@escaping (Bool) -> Void) {
        if #available(iOS 10.0, *) {
            CoreDataManager.sharedInstance.persistentContainer.performBackgroundTask { (context) in
                for user in userModel {
                    let entity = NSEntityDescription.entity(forEntityName: Constant.userListEntityName(), in: context)!
                    let userObj: Users = NSManagedObject(entity: entity, insertInto: context) as! Users
                    
                    if let id = SharedPreferences.getUserId() {
                        userObj.id = id
                        userObj.userId = user.userId
                        if let customField = user.customFields {
                            userObj.fullName = customField.fullName
                            userObj.gender = customField.gender
                            userObj.email = customField.email
                            userObj.privateEmail = customField.privateEmail
                            userObj.phone = customField.phone
                            userObj.age = customField.age! > Int64(0) ? customField.age! : 0
                            userObj.city = customField.city
                            userObj.company = customField.company
                            userObj.position = customField.position
                            userObj.companySize = customField.companySize
                            userObj.attendeeLookingFor = customField.attendeeLookingFor as NSObject?
                            userObj.attendeeProviding = customField.attendeeProviding as NSObject?
                            userObj.attendeeType = customField.attendeeType as NSObject?
                            userObj.industryTags = customField.industryTags as NSObject?
                            userObj.industryComplimentaryTags = customField.industryComplimentaryTags as NSObject?
                            userObj.positionType = customField.positionType as NSObject?
                            userObj.likes = user.likes
                            userObj.imageUrl = user.media.count > 0 ? user.media[0].profilePicture : ""
                        }
                        else {
                            userObj.fullName = ""
                            userObj.gender = ""
                            userObj.email = ""
                            userObj.privateEmail = ""
                            userObj.phone = ""
                            userObj.age = 0
                            userObj.city = ""
                            userObj.company = ""
                            userObj.position = ""
                            userObj.companySize = ""
                            userObj.attendeeLookingFor = [""] as NSObject?
                            userObj.attendeeProviding = [""] as NSObject?
                            userObj.attendeeType = [""] as NSObject?
                            userObj.industryTags = [""] as NSObject?
                            userObj.industryComplimentaryTags = [""] as NSObject?
                            userObj.positionType = [""] as NSObject?
                            userObj.likes = 0
                            userObj.imageUrl = ""
                        }
                    }
                    do {
                        try context.save()
                    } catch let error as NSError {
                        print("Could not save. \(error), \(error.userInfo)")
                    }
                }
                completion(true)
            }
        }
    }
}

class CustomField: Mappable {
    var fullName: String?
    var privateEmail: String?
    var email: String?
    var company: String?
    var position: String?
    var gender: String?
    var phone: String?
    var city: String?
    var age: Int64?
    var attendeeProviding: [String]?
    var attendeeLookingFor: [String]?
    var positionType: [String]?
    var attendeeType: [String]?
    var industryTags: [String]?
    var industryComplimentaryTags: [String]?
    var companySize: String?
    
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        fullName <- map["fullName"]
        privateEmail <- map["email"]
        email <- map["publicEmail"]
        company <- map["company"]
        position <- map["position"]
        gender <- map["gender"]
        phone <- map["phone"]
        city <- map["city"]
        age <- map["age"]
        attendeeProviding <- map["attendeeProviding"]
        attendeeLookingFor <- map["attendeeLookingFor"]
        positionType <- map["positionType"]
        attendeeType <- map["attendeeType"]
        industryTags <- map["industryTags"]
        industryComplimentaryTags <- map["industryComplimentaryTags"]
        companySize <- map["companySize"]
    }
}

class Media: Mappable {
    var profilePicture: String!
    
    required init?(map: Map) {
    }
 
    func mapping(map: Map) {
        profilePicture <- map["files.variations.original"]
    }
}
