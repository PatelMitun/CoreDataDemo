//
//  FilterModel.swift
//  FestivalityTrial
//
//  Created by TechFlitter Solutions on 14/06/18.
//  Copyright © 2018 TechFlitter Solutions. All rights reserved.
//

import Foundation
import ObjectMapper

class FilterModel: Mappable {
    
    lazy var attendeeProviding: [FilterDetailModel] = []
    lazy var attendeeLookingFor: [FilterDetailModel] = []
    
    required init?() {
    }
    
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        attendeeProviding <- map["attendeeLookingFor"]
        attendeeLookingFor <- map["attendeeLookingFor"]
    }
}

class FilterDetailModel: Mappable {
    
    var name: String!
    var isSelect: Bool = false
    
    required init?() {
    }
    
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        name <- map["name"]
        isSelect <- map["isSelect"]
    }
}
