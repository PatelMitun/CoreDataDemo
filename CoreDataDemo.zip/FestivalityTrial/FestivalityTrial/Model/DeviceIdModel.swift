//
//  DeviceIdModel.swift
//  FestivalityTrial
//
//  Created by TechFlitter Solutions on 10/06/18.
//  Copyright © 2018 TechFlitter Solutions. All rights reserved.
//

import Foundation
import ObjectMapper

class DeviceIdModel: Mappable {
    
    var status: Int64!
    var deviceId: String!
    
    required init?(map: Map) {
        
    }
    
    // Mappable
    func mapping(map: Map) {
        status <- map["status"]
        deviceId <- map["response.deviceId"]
    }
    
}
