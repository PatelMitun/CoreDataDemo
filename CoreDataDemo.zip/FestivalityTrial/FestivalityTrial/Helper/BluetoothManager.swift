//
//  BluetoothManager.swift
//  FestivalityTrial
//
//  Created by TechFlitter Solutions on 10/06/18.
//  Copyright © 2018 TechFlitter Solutions. All rights reserved.
//

import Foundation
import UIKit
import CoreBluetooth

class BluetoothManager: NSObject, CBCentralManagerDelegate, CBPeripheralDelegate {
    
    fileprivate var discoveredPeripheral: CBPeripheral?
    fileprivate var centralManager: CBCentralManager?
    
    static let sharedInstance: BluetoothManager = {
        let instance = BluetoothManager()
        return instance
    }()
    
    func configureBluetooth() {
        centralManager = CBCentralManager(delegate: self, queue: nil)
        discoveredPeripheral?.delegate = self
    }
    
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch central.state {
        case .poweredOn:
            break
        default:
            break
        }
    }
}
