//
//  Extension.swift
//  FestivalityTrial
//
//  Created by TechFlitter Solutions on 15/06/18.
//  Copyright © 2018 TechFlitter Solutions. All rights reserved.
//

import Foundation
import UIKit

extension Notification.Name {
    enum FestivalTrial {
        static let GetUserList = Notification.Name(rawValue: "Notification.GetUserList")
        static let GetUserDetail = Notification.Name(rawValue: "Notification.GetUserDetail")
    }
}

extension Array {
    func filterDuplicates(includeElement: @escaping (_ lhs:Element, _ rhs:Element) -> Bool) -> [Element] {
        var results = [Element]()
        forEach { (element) in
            let existingElements = results.filter {
                return includeElement(element, $0)
            }
            if existingElements.count == 0 {
                results.append(element)
            }
        }
        return results
    }
}

extension UILabel {
    @IBInspectable var isDynamicFontLabel:Bool  {
        set {
            if newValue {
                let fontSize = font.pointSize
                let currentFontName = self.font.fontName
                var calculatedFont: UIFont?
                let bounds = UIScreen.main.bounds
                let height = bounds.size.height
                switch height {
                case 480.0:
                    calculatedFont = UIFont(name: currentFontName, size: fontSize * 0.8)
                    self.font = calculatedFont
                    break
                case 568.0:
                    calculatedFont = UIFont(name: currentFontName, size: fontSize * 0.9)
                    self.font = calculatedFont
                    break
                case 667.0:
                    calculatedFont = UIFont(name: currentFontName, size: fontSize)
                    self.font = calculatedFont
                    break
                case 736.0:
                    calculatedFont = UIFont(name: currentFontName, size: fontSize * 1.1)
                    self.font = calculatedFont
                    break
                default:
                    break
                }
            }
        }
        get{
            return self.isDynamicFontLabel
        }
    }
}

extension UIButton {
    @IBInspectable var isDynamicFontButton:Bool  {
        set {
            if newValue {
                let fontSize = self.titleLabel?.font.pointSize
                let currentFontName = self.titleLabel?.font.fontName
                var calculatedFont: UIFont?
                let bounds = UIScreen.main.bounds
                let height = bounds.size.height
                switch height {
                case 480.0:
                    calculatedFont = UIFont(name: currentFontName!, size: fontSize!)
                    self.titleLabel?.font = calculatedFont
                    break
                case 568.0:
                    calculatedFont = UIFont(name: currentFontName!, size: fontSize! * 0.9)
                    self.titleLabel?.font = calculatedFont
                    break
                case 667.0:
                    calculatedFont = UIFont(name: currentFontName!, size: fontSize!)
                    self.titleLabel?.font = calculatedFont
                    break
                case 736.0:
                    calculatedFont = UIFont(name: currentFontName!, size: fontSize! * 1.1)
                    self.titleLabel?.font = calculatedFont
                    break
                default:
                    break
                }
            }
        }
        get{
            return self.isDynamicFontButton
        }
    }
}
