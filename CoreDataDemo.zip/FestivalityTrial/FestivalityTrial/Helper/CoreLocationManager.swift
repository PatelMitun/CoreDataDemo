//
//  CoreLocationManager.swift
//  FestivalityTrial
//
//  Created by TechFlitter Solutions on 10/06/18.
//  Copyright © 2018 TechFlitter Solutions. All rights reserved.
//

import Foundation
import CoreLocation

typealias responseBlock = (Bool,Any?) -> Void

protocol LocationAutorizationDelegate {
    func tracingAuthorization(status: CLAuthorizationStatus)
}

class LocationService: NSObject, CLLocationManagerDelegate {
    
    static let sharedInstance: LocationService = {
        let instance = LocationService()
        return instance
    }()
    
    var locationManager: CLLocationManager?
    var authDelegate: LocationAutorizationDelegate?

    override init() {
        super.init()
        
        self.locationManager = CLLocationManager()
        guard let locationManager = self.locationManager else {
            return
        }
        locationManager.delegate = self
        locationManager.requestAlwaysAuthorization()
    }
    
    func requestAlwaysAuthorization() {
        locationManager?.requestAlwaysAuthorization()
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        guard let authDelegate = self.authDelegate else {
            return
        }
        authDelegate.tracingAuthorization(status: status)
    }
    
    func isLocationServiceEnabled() -> Bool {
        if CLLocationManager.locationServicesEnabled() {
            switch(CLLocationManager.authorizationStatus()) {
            case .notDetermined:
                self.requestAlwaysAuthorization()
                return true
            case .restricted, .denied :
                return false
            default:
                return true
            }
        } else {
            return false
        }
    }
}
