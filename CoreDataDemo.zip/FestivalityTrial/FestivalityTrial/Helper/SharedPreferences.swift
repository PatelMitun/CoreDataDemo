//
//  SharedPreferences.swift
//  FestivalityTrial
//
//  Created by Nishant on 15/06/18.
//  Copyright © 2018 TechFlitter Solutions. All rights reserved.
//

import UIKit

class SharedPreferences: NSObject {
    class func setDeviceId(deviceId: String) {
        UserDefaults.standard.set(deviceId, forKey: "deviceId")
        UserDefaults.standard.synchronize()
    }
    
    class func getDeviceId() -> String? {
        return UserDefaults.standard.value(forKey: "deviceId") as? String
    }
    
    class func setUserId(userId: Int64) {
        UserDefaults.standard.set(userId, forKey: "userId")
        UserDefaults.standard.synchronize()
    }
    
    class func getUserId() -> Int64? {
        return UserDefaults.standard.value(forKey: "userId") as? Int64
    }
    
    class func getPermission() -> Bool {
        return UserDefaults.standard.bool(forKey: "isCheckPermission")
    }
    
    class func setPermission(isPermission: Bool) {
        UserDefaults.standard.set(isPermission, forKey: "isCheckPermission")
        UserDefaults.standard.synchronize()
    }
    
    class func isTutorialLoaded() -> Bool {
        return UserDefaults.standard.bool(forKey: "isFirstTime")
    }
    
    class func setTutorialLoaded(isFirstTime: Bool) {
        UserDefaults.standard.set(isFirstTime, forKey: "isFirstTime")
        UserDefaults.standard.synchronize()
    }
    
    class func setAttendeeDetail(attendeeLookingFor: [String], attendeeProviding: [String]) {
        UserDefaults.standard.set(attendeeLookingFor, forKey: "attendeeLookingFor")
        UserDefaults.standard.set(attendeeProviding, forKey: "attendeeProviding")
        UserDefaults.standard.synchronize()
    }
    
    class func isDataSync() -> Bool {
        return UserDefaults.standard.bool(forKey: "isDataSync")
    }
    
    class func setDataSync(isDataSync: Bool) {
        UserDefaults.standard.set(isDataSync, forKey: "isDataSync")
        UserDefaults.standard.synchronize()
    }
    
    class func getAttendeeLookingFor() -> [String]? {
        return UserDefaults.standard.value(forKey: "attendeeLookingFor") as? [String]
    }
    
    class func getAttendeeProviding() -> [String]? {
        return UserDefaults.standard.value(forKey: "attendeeProviding") as? [String]
    }
}
