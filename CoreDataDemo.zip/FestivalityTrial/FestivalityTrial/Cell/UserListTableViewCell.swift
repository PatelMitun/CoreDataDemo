//
//  UserListTableViewCell.swift
//  FestivalityTrial
//
//  Created by TechFlitter Solutions on 13/06/18.
//  Copyright © 2018 TechFlitter Solutions. All rights reserved.
//

import UIKit
import SDWebImage

class UserListTableViewCell: FoldingTableViewCell {

    @IBOutlet weak var userProfileImageView: UIImageView!
    
    @IBOutlet weak var userNameLabel: UILabel!
    
    @IBOutlet weak var emailLabel: UILabel!
    
    @IBOutlet weak var companyNameLabel: UILabel!
    
    @IBOutlet weak var cityNameLabel: UILabel!
    
    @IBOutlet weak var userImageView: UIImageView!
    
    @IBOutlet weak var fullNameLabel: UILabel!
    
    @IBOutlet weak var publicEmailLabel: UILabel!
    
    @IBOutlet weak var likeLabel: UILabel!
    
    @IBOutlet weak var companyLabel: UILabel!
    
    @IBOutlet weak var positionLabel: UILabel!
    
    @IBOutlet weak var companySizeLabel: UILabel!
    
    @IBOutlet weak var contactNumberLabel: UILabel!
    
    @IBOutlet weak var privateEmailLabel: UILabel!
    
    @IBOutlet weak var ageLabel: UILabel!
    
    @IBOutlet weak var cityLabel: UILabel!
    
    func setDefaultValue() {
        self.userNameLabel.text = "-"
        self.fullNameLabel.text = "-"
        self.emailLabel.text = "-"
        self.publicEmailLabel.text = "-"
        companyNameLabel.text = "-"
        companyLabel.text = "Name: - "
        cityNameLabel.text = "-"
        positionLabel.text = "Position: -"
        companySizeLabel.text = "Company Size: -"
        contactNumberLabel.text = "Contact: -"
        privateEmailLabel.text = "Email(Private): -"
        cityLabel.text = "City: -"
    }
    
    func configureCell(user: Users?) {
        self.setDefaultValue()
        
        if let user = user {
            if let url = user.imageUrl {
                userProfileImageView.sd_setImage(with: URL(string: url) , placeholderImage: #imageLiteral(resourceName: "profileImage"))
                userImageView.sd_setImage(with: URL(string: url) , placeholderImage: #imageLiteral(resourceName: "profileImage"))
            }
            
            if let userName = user.fullName {
                userNameLabel.text = userName.count > 0 ? userName : "-"
                fullNameLabel.text = userName.count > 0 ? userName : "-"
            }
            
            if let email = user.email {
                emailLabel.text = email.count > 0 ? email : "-"
                publicEmailLabel.text = email.count > 0 ? email : "-"
            }
            
            if let company = user.company {
                companyNameLabel.text = company.count > 0 ? company : "-"
                companyLabel.text = "Name: " + String.init(stringLiteral: (String(company.count > 0 ? company : "-")))
            }
            
            if let city = user.city {
                cityNameLabel.text = city.count > 0 ? city : "-"
            }
            
            if let position = user.position {
                positionLabel.text = "Position: " +  String.init(stringLiteral: (String(position.count > 0 ? position : "-")))
            }
            
            if let companySize = user.companySize {
                companySizeLabel.text = "Company Size: " + String.init(stringLiteral: (String(companySize.count > 0 ? companySize : "-")))
            }
            
            if let contactNumber = user.phone {
                contactNumberLabel.text = "Contact: " + String.init(stringLiteral: (String(contactNumber.count > 0 ? contactNumber : "-")))
            }
            
            if let publicEmail = user.email {
                privateEmailLabel.text = "Email(Private): " + String.init(stringLiteral: (String(publicEmail.count > 0 ? publicEmail : "-")))
            }
            
            ageLabel.text = "Age: " + String.init(stringLiteral: (String((user.age) > 0 ? "\(user.age)" : "-")))
            likeLabel.text = String("\(user.likes)")
            
            if let city = user.city {
                cityLabel.text = "City: " +  String.init(stringLiteral: (String(city.count > 0 ? city : "-")))
            }
        }
    }
    
    override func awakeFromNib() {
        foregroundView.layer.cornerRadius = 10
        foregroundView.layer.masksToBounds = true
        
        if let imageView = self.userProfileImageView {
            imageView.layer.cornerRadius = imageView.frame.size.width / 2
            imageView.clipsToBounds = true
        }
        if let imageView = self.userImageView {
            imageView.layer.cornerRadius = imageView.frame.size.width / 2
            imageView.clipsToBounds = true
        }
        super.awakeFromNib()
    }
    
    override func animationDuration(_ itemIndex: NSInteger, type _: FoldingTableViewCell.AnimationType) -> TimeInterval {
        let durations = [0.26, 0.2, 0.2]
        return durations[itemIndex]
    }
}
