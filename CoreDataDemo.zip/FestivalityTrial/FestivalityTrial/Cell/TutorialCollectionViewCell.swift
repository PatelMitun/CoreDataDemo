//
//  TutorialCollectionViewCell.swift
//  FestivalityTrial
//
//  Created by TechFlitter Solutions on 10/06/18.
//  Copyright © 2018 TechFlitter Solutions. All rights reserved.
//

import UIKit

class TutorialCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var tutorialImageView: UIImageView!
    
    @IBOutlet weak var skipButton: UIButton!
    
    @IBOutlet weak var tutorialHeaderLabel: UILabel!
    
    @IBOutlet weak var tutorialDescriptionLabel: UILabel!
    
    @IBOutlet weak var permissionButton: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        if let permissionButton = self.permissionButton {
            permissionButton.layer.borderColor = UIColor.white.cgColor
            permissionButton.layer.borderWidth = 1.0
            permissionButton.layer.cornerRadius = 5.0
            permissionButton.clipsToBounds = true
        }
    }
}
