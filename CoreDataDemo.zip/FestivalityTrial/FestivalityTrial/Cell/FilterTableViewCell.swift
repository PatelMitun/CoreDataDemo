//
//  FilterTableViewCell.swift
//  FestivalityTrial
//
//  Created by TechFlitter Solutions on 14/06/18.
//  Copyright © 2018 TechFlitter Solutions. All rights reserved.
//

import UIKit

class FilterTableViewCell: UITableViewCell {

    @IBOutlet weak var filterButton: UIButton!
    @IBOutlet weak var filterLabel: UILabel!
}
