//
//  ViewController.swift
//  FestivalityTrial
//
//  Created by TechFlitter Solutions on 10/06/18.
//  Copyright © 2018 TechFlitter Solutions. All rights reserved.
//

import UIKit

class PromoViewController: UIViewController {

    @IBOutlet weak var moreButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if SharedPreferences.getPermission() {
            self.checkPermission()
        }
        
        if !SharedPreferences.isTutorialLoaded() {
            self.presentTutorialView()
            SharedPreferences.setTutorialLoaded(isFirstTime: true)
        }
        
        self.moreButton.layer.cornerRadius = self.moreButton.frame.size.height / 2.0
        self.moreButton.layer.borderColor = UIColor.white.cgColor
        self.moreButton.layer.borderWidth = 1.0
        self.moreButton.clipsToBounds = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

extension PromoViewController {
    func presentTutorialView() {
        let tutorialViewController = self.storyboard?.instantiateViewController(withIdentifier: "TutorialViewController") as! TutorialViewController
        self.present(tutorialViewController, animated: true, completion: nil)
    }
    
    //MARK: Action
    @IBAction func viewMoreClicked(_ sender: UIButton) {
        let userListViewController = self.storyboard?.instantiateViewController(withIdentifier: "UserListViewController") as! UserListViewController
        self.navigationController?.pushViewController(userListViewController, animated: true)
    }
    
    func checkPermission() {
        SharedPreferences.setPermission(isPermission: true)
        if !NotificationManager.sharedInstance.isNotificationEnabled() {
            let alert = UIAlertController(title: "Festivality Trial", message: "Enable notification access from your iPhone settings.", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Settings", style: UIAlertActionStyle.default, handler: {(alertAction) in
                let settingsURL = URL(string: UIApplicationOpenSettingsURLString)
                UIApplication.shared.openURL(settingsURL!)
            }))
            alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel, handler: {(alertAction) in
            }))
            self.present(alert, animated: true, completion: nil)
        }
        
        if !LocationService.sharedInstance.isLocationServiceEnabled() {
            let alert = UIAlertController(title: "Festivality Trial", message: "Enable location access from your iPhone settings.", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Settings", style: UIAlertActionStyle.default, handler: {(alertAction) in
                let settingsURL = URL(string: UIApplicationOpenSettingsURLString)
                UIApplication.shared.openURL(settingsURL!)
            }))
            alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel, handler: {(alertAction) in
            }))
            self.present(alert, animated: true, completion: nil)
        }
    }
}
