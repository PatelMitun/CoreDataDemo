//
//  UserListPresenter.swift
//  FestivalityTrial
//
//  Created by TechFlitter Solutions on 10/06/18.
//  Copyright © 2018 TechFlitter Solutions. All rights reserved.
//

import Foundation
class UserListPresenter {
    
    let provider: UserListProvider
    weak private var userListView: UserListView?
    
    // MARK: - Initialization & Configuration
    init(provider: UserListProvider) {
        self.provider = provider
    }
    
    func attachView(view: UserListView?) {
        guard let view = view else { return }
        userListView = view
    }
    
    // MARK: - Perform Get User List
    func getUserList() {
        provider.getUserList(successHandler: { (response) in
            CoreDataManager.sharedInstance.deleteWithPrediecate(entityName: Constant.userListEntityName() as NSString,
                                                                predicate: NSPredicate(format: "id = \(SharedPreferences.getUserId()!)"))
            let userModel = UserModel()
            _ = userModel?.saveAll(userModel: response.userModel,completion: {_ in
                SharedPreferences.setDataSync(isDataSync: true)
                NotificationCenter.default.post(name: Notification.Name.FestivalTrial.GetUserList, object: nil)
            })

        }, errorHandler: { (error) in
            self.userListView?.finishUserListWithError(error as? Dictionary<String, Any>)
        })
    }
    
    func getUserDetail() {
        provider.getUserDetail(successHandler: { (response) in
            if let users = response.userModel {
                for user: UserModel in users {
                    SharedPreferences.setAttendeeDetail(attendeeLookingFor: user.customFields.attendeeLookingFor!, attendeeProviding: user.customFields.attendeeProviding!)
                }
            }
        }, errorHandler: { (error) in
            self.userListView?.finishUserListWithError(error as? Dictionary<String, Any>)
        })
    }
}
