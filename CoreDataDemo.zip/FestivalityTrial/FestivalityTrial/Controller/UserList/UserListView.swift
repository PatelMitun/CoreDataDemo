//
//  UserListView.swift
//  FestivalityTrial
//
//  Created by TechFlitter Solutions on 10/06/18.
//  Copyright © 2018 TechFlitter Solutions. All rights reserved.
//

import Foundation
protocol UserListView: class {
    func getUserListWithSuccess()
    func finishUserListWithError(_ error: Dictionary<String, Any>?)
}
