//
//  UserListViewController.swift
//  FestivalityTrial
//
//  Created by TechFlitter Solutions on 10/06/18.
//  Copyright © 2018 TechFlitter Solutions. All rights reserved.
//

import UIKit
import RappleProgressHUD

class UserListViewController: UIViewController {
    let userlistPresenter = UserListPresenter(provider: UserListProvider())
    
    let closeCellHeight: CGFloat = 148
    let openCellHeight: CGFloat = 532
    var cellHeights: [CGFloat] = []
    var userList = [Users]()
    var filteredUserList = [Users]()
    var delegate: FilterDelegate?
    var filterModel: FilterModel?

    @IBOutlet weak var userListTableView: UITableView!
    @IBOutlet weak var noDataLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = false
        self.title = "Attendee List"
        self.navigationItem.setHidesBackButton(true, animated: false)
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(image: #imageLiteral(resourceName: "refresh"), style: .plain, target: self, action: #selector(refreshClicked))

        self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: #imageLiteral(resourceName: "filter"), style: .plain, target: self, action: #selector(filterClicked))
        userlistPresenter.attachView(view: self)
        initView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(reloadUserList),
                                               name: NSNotification.Name.FestivalTrial.GetUserList, object: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.FestivalTrial.GetUserList, object: nil)
    }
}

extension UserListViewController {
    func initView() {
        if let userId = SharedPreferences.getUserId() {
            userList = CoreDataManager.sharedInstance.fetchWithPredicate(entityName: Constant.userListEntityName() as NSString, predicate: NSPredicate(format: "id = \(userId)")) as! [Users]
            if userList.count == 0 {
                self.startIndicator()
            }
            filteredUserList = userList
            cellHeights = Array(repeating: closeCellHeight, count: filteredUserList.count)
            userListTableView.estimatedRowHeight = closeCellHeight
            userListTableView.rowHeight = UITableViewAutomaticDimension
            userListTableView.backgroundColor = UIColor(patternImage: #imageLiteral(resourceName: "background"))
            self.reloadTableView()
            self.noDataLabel.isHidden = true
        }
        else {
            self.noDataLabel.isHidden = false
        }
    }
    
    //MARK: Action
    @objc func filterClicked() {
        let filterViewController = self.storyboard?.instantiateViewController(withIdentifier: "FilterViewController") as! FilterViewController
        filterViewController.delegate = self
        filterViewController.lastFilteredData = self.filterModel
        self.navigationController?.pushViewController(filterViewController, animated: true)
    }
    
    @objc func reloadUserList() {
        userList = CoreDataManager.sharedInstance.fetchWithPredicate(entityName: Constant.userListEntityName() as NSString, predicate: NSPredicate(format: "id = \(SharedPreferences.getUserId()!)")) as! [Users]
        filteredUserList = userList
        cellHeights = Array(repeating: closeCellHeight, count: filteredUserList.count)
        self.endIndicator()
        self.reloadTableView()
    }
    
    @objc func refreshClicked() {
        self.startIndicator()
        self.filterModel = nil
        userlistPresenter.getUserList()
    }
    
    func reloadTableView() {
        DispatchQueue.main.async {
            self.userListTableView.reloadData()
        }
    }
    
    func startIndicator() {
        RappleActivityIndicatorView.startAnimatingWithLabel("Loading", attributes: Constant.rappleProgressAttributes())
    }
    
    func endIndicator() {
        RappleActivityIndicatorView.stopAnimation()
    }
}

extension UserListViewController: UserListView {
    func getUserListWithSuccess() {
        reloadUserList()
    }
    
    func finishUserListWithError(_ error: Dictionary<String, Any>?) {
    }
}

extension UserListViewController: FilterDelegate {
    @objc func getFilter(filter: AnyObject) {
        if let filter = filter as? FilterModel {
            self.filterModel = filter
            let attendeeLooking = getSelectedAttendeeList(filterList: filter.attendeeLookingFor)
            let attendeeProviding = getSelectedAttendeeList(filterList: filter.attendeeProviding)
            var filterArray = [Users]()
            var isFiltered = false
            if attendeeLooking.count > 0 {
                isFiltered = true
                for looking in attendeeLooking {
                    let attendeeProvidingArray = userList.filter({(($0.attendeeProviding as? [String])?.contains(looking))!})
                    for attendee in attendeeProvidingArray {
                        filterArray.append(attendee)
                    }
                }
            }
            if attendeeProviding.count > 0 {
                isFiltered = true
                for providingFor in attendeeProviding {
                    let attendeeLookingArray = userList.filter({(($0.attendeeLookingFor as? [String])?.contains(providingFor))!})
                    for attendee in attendeeLookingArray {
                        filterArray.append(attendee)
                    }
                }
            }
            filteredUserList = filterArray.filterDuplicates { $0.userId == $1.userId}
            if !isFiltered {
                self.filteredUserList = self.userList
            }
            self.noDataLabel.isHidden = filteredUserList.count > 0
            self.reloadTableView()
        }
    }
    
    func getSelectedAttendeeList(filterList: [FilterDetailModel]) -> [String] {
        var attendeeList:[String] = []
        for attendee in filterList {
            if attendee.isSelect {
                attendeeList.append(attendee.name)
            }
        }
        return attendeeList
    }
}

// MARK: - TableView

extension UserListViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_: UITableView, numberOfRowsInSection _: Int) -> Int {
        return filteredUserList.count
    }
    
    func tableView(_: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        guard case let cell as UserListTableViewCell = cell else {
            return
        }
        cell.backgroundColor = .clear
        
        if cellHeights[indexPath.row] == closeCellHeight {
            cell.unfold(false, animated: false, completion: nil)
        } else {
            cell.unfold(true, animated: false, completion: nil)
        }
        
        cell.configureCell(user: self.filteredUserList[indexPath.item])
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "userListCell", for: indexPath) as! FoldingTableViewCell
        let durations: [TimeInterval] = [0.26, 0.2, 0.2]
        cell.durationsForExpandedState = durations
        cell.durationsForCollapsedState = durations
        return cell
    }
    
    func tableView(_: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return cellHeights[indexPath.row]
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let cell = tableView.cellForRow(at: indexPath) as! FoldingTableViewCell
        
        if cell.isAnimating() {
            return
        }
        
        var duration = 0.0
        let collapsedCell = cellHeights[indexPath.row] == closeCellHeight
        if collapsedCell {
            cellHeights[indexPath.row] = openCellHeight
            cell.unfold(true, animated: true, completion: nil)
            duration = 0.5
        } else {
            cellHeights[indexPath.row] = closeCellHeight
            cell.unfold(false, animated: true, completion: nil)
            duration = 0.8
        }
        
        UIView.animate(withDuration: duration, delay: 0, options: .curveEaseOut, animations: { () -> Void in
            tableView.beginUpdates()
            tableView.endUpdates()
        }, completion: nil)
    }
}
