//
//  UserListProvider.swift
//  FestivalityTrial
//
//  Created by TechFlitter Solutions on 10/06/18.
//  Copyright © 2018 TechFlitter Solutions. All rights reserved.
//

import Foundation
class UserListProvider {
    func getUserList(successHandler: @escaping (_ response: UsersModel) -> Void,
                       errorHandler: @escaping (_ error: Error) -> Void) {
        if let _ = SharedPreferences.getDeviceId() {
            NetworkManager.makeRequest(FestivalTrialHttpRouter.getUserList(), message: "", showProgress: false).onSuccess { (response: UsersModel) in
                successHandler(response)
                }.onFailure { (error) in
            }
        }
        else {
            NetworkManager.makeRequest(FestivalTrialHttpRouter.getDeviceId(), message: "", showProgress: false)
                .onSuccess { (response: DeviceIdModel) in
                    print(response)
                    SharedPreferences.setDeviceId(deviceId: response.deviceId)
                    SharedPreferences.setUserId(userId: 44779)
                    NetworkManager.makeRequest(FestivalTrialHttpRouter.getUserList(), message: "", showProgress: false)
                        .onSuccess { (response: UsersModel) in
                            successHandler(response)
                        }
                        .onFailure { error in
                        }.onComplete { _ in
                    }
                }
                .onFailure { error in
                }.onComplete { _ in
            }
        }
    }
    
    func getUserDetail(successHandler: @escaping (_ response: UsersModel) -> Void,
                       errorHandler: @escaping (_ error: Error) -> Void) {
        if let _ = SharedPreferences.getDeviceId(), let userId = SharedPreferences.getUserId()  {
            NetworkManager.makeRequest(FestivalTrialHttpRouter.getUserDetail(userId: userId), message: "", showProgress: false).onSuccess { (response: UsersModel) in
                successHandler(response)
                }.onFailure { (error) in
            }
        }
        else {
            NetworkManager.makeRequest(FestivalTrialHttpRouter.getDeviceId(), message: "", showProgress: false)
                .onSuccess { (response: DeviceIdModel) in
                    SharedPreferences.setDeviceId(deviceId: response.deviceId)
                    SharedPreferences.setUserId(userId: 44779)
                    NetworkManager.makeRequest(FestivalTrialHttpRouter.getUserDetail(userId: Int64(SharedPreferences.getUserId()!)), message: "", showProgress: false)
                        .onSuccess { (response: UsersModel) in
                            successHandler(response)
                        }
                        .onFailure { error in
                        }.onComplete { _ in
                    }
                }
                .onFailure { error in
                }.onComplete { _ in
            }
        }
    }
}
