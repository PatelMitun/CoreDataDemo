//
//  FilterViewController.swift
//  FestivalityTrial
//
//  Created by TechFlitter Solutions on 14/06/18.
//  Copyright © 2018 TechFlitter Solutions. All rights reserved.
//

import UIKit

@objc protocol FilterDelegate {
   @objc func getFilter(filter: AnyObject)
}

class FilterViewController: UIViewController {

    @IBOutlet weak var filterTableView: UITableView!
    
    var attandeeProviding: [String]!
    var attandeeLookingFor: [String]!
    var filterModel = FilterModel()
    var lastFilteredData = FilterModel()
    weak var delegate: FilterDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationController?.isNavigationBarHidden = false
        self.title = "Filter"
        self.navigationItem.setHidesBackButton(true, animated: false)
        
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(image: #imageLiteral(resourceName: "back"), style: .plain, target: self, action: #selector(backClicked))
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Clear", style: .plain, target: self, action: #selector(clearFilter))
        
        initView()
    }
}

extension FilterViewController {
    
    func initView() {
        if let attendeeLookingFor = SharedPreferences.getAttendeeLookingFor(),
            let attendeeProviding = SharedPreferences.getAttendeeProviding() {
            self.attandeeLookingFor = attendeeLookingFor
            self.attandeeProviding = attendeeProviding
        }
        
        for attendeeProviding in self.attandeeProviding {
            let filterDetailModel = FilterDetailModel()
            filterDetailModel?.name = attendeeProviding
            filterDetailModel?.isSelect = false
            if let lastAttandees = lastFilteredData?.attendeeProviding, lastAttandees.count > 0  {
                for lastAttandee in lastAttandees {
                    if lastAttandee.name == attendeeProviding {
                        filterDetailModel?.isSelect = true
                    }
                }
            }
            self.filterModel?.attendeeProviding.append(filterDetailModel!)
        }
        
        for attendeeProviding in self.attandeeLookingFor {
            let filterDetailModel = FilterDetailModel()
            filterDetailModel?.name = attendeeProviding
            filterDetailModel?.isSelect = false
            if let lastlookindfor = lastFilteredData?.attendeeLookingFor, lastlookindfor.count > 0  {
                for lookindfor in lastlookindfor {
                    if lookindfor.name == attendeeProviding {
                        filterDetailModel?.isSelect = true
                    }
                }
            }
            self.filterModel?.attendeeLookingFor.append(filterDetailModel!)
        }
        self.filterTableView.reloadData()
    }
    
    func filterRedirection() {
        lastFilteredData = FilterModel()
        lastFilteredData?.attendeeLookingFor = getselectedAttendeeList(filterDetail: (self.filterModel?.attendeeLookingFor)!)
        lastFilteredData?.attendeeProviding = getselectedAttendeeList(filterDetail: (self.filterModel?.attendeeProviding)!)
        _ = self.delegate?.getFilter(filter: self.lastFilteredData as AnyObject)
        self.navigationController?.popViewController(animated: true)
    }
    
    func getselectedAttendeeList(filterDetail: [FilterDetailModel]) -> [FilterDetailModel] {
        var attendeeList:[FilterDetailModel] = []
        for attendee in filterDetail {
            if attendee.isSelect {
                attendeeList.append(attendee)
            }
        }
        return attendeeList
    }
    
    //MARK: Action
    @objc func backClicked() {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func clearFilter() {
        if let attendeeLookingFor = self.filterModel?.attendeeLookingFor {
            for i in 0..<attendeeLookingFor.count {
                attendeeLookingFor[i].isSelect = false
            }
            self.filterModel?.attendeeLookingFor = attendeeLookingFor
        }
        if let attendeeProviding = self.filterModel?.attendeeProviding {
            for i in 0..<attendeeProviding.count {
                attendeeProviding[i].isSelect = false
            }
            self.filterModel?.attendeeProviding = attendeeProviding
        }
        filterRedirection()
    }
    
    @IBAction func filterClicked(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        let indexpath: NSIndexPath = NSIndexPath(item: (sender.tag), section: (sender.superview?.tag)!)
        if (indexpath.section == 0) {
            self.filterModel?.attendeeProviding[indexpath.row].isSelect = sender.isSelected
        } else if(indexpath.section == 1) {
            self.filterModel?.attendeeLookingFor[indexpath.row].isSelect = sender.isSelected
        }
    }
    
    @IBAction func doneClicked(_ sender: UIButton) {
        filterRedirection()
    }
}

extension FilterViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return self.attandeeProviding.count
        }
        return self.attandeeLookingFor.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "filterCell", for: indexPath) as! FilterTableViewCell
        if indexPath.section == 0 {
            cell.filterLabel.text = self.attandeeProviding[indexPath.row]
            cell.filterButton.superview?.tag = indexPath.section
            cell.filterButton.tag = indexPath.row
            cell.filterButton.isSelected = (self.filterModel?.attendeeProviding[indexPath.row].isSelect)!
        }
        else {
            cell.filterLabel.text = self.attandeeLookingFor[indexPath.row]
            cell.filterButton.superview?.tag = indexPath.section
            cell.filterButton.tag = indexPath.row
            cell.filterButton.isSelected = (self.filterModel?.attendeeLookingFor[indexPath.row].isSelect)!
        }
        return cell
    }

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if section == 0 {
            return "Attendee Providing"
        }
        return "Attendee Looking For"
    }
}
