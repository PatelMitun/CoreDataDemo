//
//  TutorialViewController.swift
//  FestivalityTrial
//
//  Created by TechFlitter Solutions on 10/06/18.
//  Copyright © 2018 TechFlitter Solutions. All rights reserved.
//

import UIKit

class TutorialViewController: UIViewController {
    
    @IBOutlet weak var tutorialCollectionView: UICollectionView!
    
    let cellIdentifier = "tutorialCell"
    var currentIndex = 0

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

extension TutorialViewController {
    //MARK: Action
    @IBAction func skipClicked(_ sender: UIButton) {
        let indexPath = IndexPath.init(item: sender.tag + 1 , section: 0)
        self.tutorialCollectionView.scrollToItem(at: indexPath, at: .left, animated: true)
    }
    
    @IBAction func permissionClicked(_ sender: UIButton) {
        if sender.tag == tutorialArray.headerArray.count - 1 {
            self.dismiss(animated: true, completion: nil)
        }
        else {
            switch sender.tag {
            case 0:
                NotificationManager.sharedInstance.registerForNotification()
            case 1:
                LocationService.sharedInstance.requestAlwaysAuthorization()
            case 2:
                BluetoothManager.sharedInstance.configureBluetooth()
            default:
                break
            }
            let indexPath = IndexPath.init(item: sender.tag + 1 , section: 0)
            self.tutorialCollectionView.scrollToItem(at: indexPath, at: .left, animated: true)
        }
    }
}

extension TutorialViewController: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout, UIScrollViewDelegate {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 4
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: cellIdentifier, for: indexPath) as! TutorialCollectionViewCell
        cell.tutorialHeaderLabel.text = tutorialArray.headerArray[indexPath.item]
        cell.tutorialDescriptionLabel.text = tutorialArray.descriptionArray[indexPath.item]
        cell.permissionButton.setTitle(tutorialArray.permisisonArray[indexPath.item], for: .normal)
        cell.skipButton.tag = indexPath.item
        cell.permissionButton.tag = indexPath.item
        if indexPath.item == tutorialArray.headerArray.count - 1 {
            cell.skipButton.isHidden = true
        }
        else {
            cell.skipButton.isHidden = false
        }
        cell.tutorialImageView.image = UIImage(named: "tutorial_\(indexPath.item)")
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.size.width, height: collectionView.frame.size.height)
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let x = scrollView.contentOffset.x
        let w = scrollView.bounds.size.width
        let currentPage = Int(ceil(x/w))
        self.currentIndex = currentPage
    }
}
