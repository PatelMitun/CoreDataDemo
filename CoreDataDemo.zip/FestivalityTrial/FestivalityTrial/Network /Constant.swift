//
//  Configuration.swift
//  FestivalityTrial
//
//  Created by TechFlitter Solutions on 10/06/18.
//  Copyright © 2018 TechFlitter Solutions. All rights reserved.
//

import Foundation
import RappleProgressHUD

class Constant: NSObject {
    class func baseURL() -> String {
        return "https://api.festivality.co/v2/"
    }
    
    class func apiClientId() -> String {
        return "testing-account-cli"
    }
    
    class func apiToken() -> String {
        return "$2y$10$C/quaRQUsrWa30hjQJuckOXbW9kIZ.W3G1TlLMYg6lr/XDUes7SM."
    }
    
    class func userListEntityName() -> String {
        return "Users"
    }
    
    class func convertJSONString(dictionary: [String: Any]) -> String {
        if let JSONData = try? JSONSerialization.data(
            withJSONObject: dictionary,
            options: []) {
            let jsonString = String(data: JSONData, encoding: .ascii)
            return jsonString!
        }
        return ""
    }
    
    class func rappleProgressAttributes() -> [String: Any] {
        return RappleActivityIndicatorView.attribute(style: RappleStyle.apple)
    }
}

struct tutorialArray {
    static let headerArray = ["Get up-to-the-minute updates.", "Enable Smart Location Awareness to work for you.", "Enable bluetooth for searching users.", ""]
    static let descriptionArray = ["Allow festival to send you important notifications like program changes, schedule and venue updates.", "Get guidance and utility from app via location directions, navigation and helpful on-site notifications", "Allow bluetooth permission for tracking ", ""]
    static let permisisonArray = ["Enable Notifications", "Enable Location", "Enable Bluetooth", "Start using the app"]
}
