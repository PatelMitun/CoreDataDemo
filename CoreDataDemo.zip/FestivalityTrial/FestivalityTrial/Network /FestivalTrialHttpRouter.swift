//
//  FestivalTrialHttpRouter.swift
//  FestivalityTrial
//
//  Created by TechFlitter Solutions on 10/06/18.
//  Copyright © 2018 TechFlitter Solutions. All rights reserved.
//

import Foundation
import Alamofire
import ObjectMapper

public enum FestivalTrialHttpRouter: URLRequestConvertible {
    case getDeviceId()
    case getUserList()
    case getUserDetail(userId: Int64)
   
    var method: Alamofire.HTTPMethod {
        switch self {
        case .getDeviceId,
             .getUserList,
             .getUserDetail:
            return .get
        }
    }
    
    var path: String {
        switch self {
        case .getDeviceId:
            return "app/deviceId"
        case .getUserList:
            return "user-list"
        case .getUserDetail(let userId):
            return "user-list/\(userId)"
        }
    }
    
    var jsonParameters: [String: Any]? {
        switch self {
        default:
            return nil
        }
    }
    
    var urlParameters: [String: Any]? {
        switch self {
        default:
            return nil
        }
    }
    
    var headerField: [String: String]? {
        switch self {
        case .getDeviceId:
            return ["x-apiclient" : Constant.convertJSONString(dictionary: ["apiClientId" : Constant.apiClientId(),
                                                                            "apiToken" : Constant.apiToken()]) ]
        case .getUserList, .getUserDetail(_):
            return ["x-apiclient" : Constant.convertJSONString(dictionary: ["apiClientId" : Constant.apiClientId(),
                                                                            "apiToken" : Constant.apiToken()]),
                    "x-header-request" : Constant.convertJSONString(dictionary: ["deviceId" : SharedPreferences.getDeviceId() ?? ""])]
        }
    }
    
    public func asURLRequest() throws -> URLRequest {
        let url = URL.init(string: Constant.baseURL()+path)
        var urlRequest = URLRequest(url: url!)
        urlRequest.httpMethod = method.rawValue
        
        urlRequest.allHTTPHeaderFields = headerField
        
        switch self {
        case .getDeviceId,
             .getUserList,
             .getUserDetail:
            return try URLEncoding.queryString.encode(urlRequest, with: self.urlParameters)
        }
    }
}
